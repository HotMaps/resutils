# resutils

Package with some common function for the Solar and wind module. Especially

 - unit.py, containts the function for fixing the best unit for the result file
 - rester.py, contains function to get lat long coordinates and for working with raster files
 - output.py to write the output json and to test it
